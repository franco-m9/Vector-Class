/*
Franco Marcoccia
10/04/2018
COP4530
Vector Class Template Container
*/

#include "Vector.h"

template <typename T>	
Vector<T>::Vector(): theSize{0}, theCapacity{0}, array{nullptr}									// default constructor
{ 
}

template <typename T>      
Vector<T>::Vector( const Vector & rhs ): theSize{ rhs.theSize }, theCapacity{ rhs.theCapacity }, array{ nullptr } 		// copy constructor
{ 
array = new T[ theCapacity ];
for( int k = 0; k < theSize; ++k )
array[ k ] = rhs.array[ k ];
}

template <typename T>	
Vector<T>::Vector( Vector && rhs ) : theSize{ rhs.theSize }, theCapacity{ rhs.theCapacity }, array{ rhs.array }        		// move constructor
{
rhs.array = nullptr;
rhs.theSize = 0;
rhs.theCapacity = 0;
}

template <typename T>
Vector<T>::Vector(int num, const T & val): theSize{num}, theCapacity{num} 							// initialized constructor
{
array = new T[theCapacity];
for (int i=0; i<theSize; i++)
array[i]=val;
}

template <typename T>
Vector<T>::Vector(const_iterator start, const_iterator end): theSize{0}, theCapacity{0}							
{
auto range = end - start;
array = new T[range];
for(auto itr = start; itr<end; ++itr)
	push_back(*itr);
}

template <typename T>	
Vector<T>::~Vector( )														// destructor
{
delete [ ] array;
}

template <typename T>
T & Vector<T>::operator[]( int index )
{
return array[ index ];                                                                                        			// no error checking
}

template <typename T>
const Vector<T> & Vector<T>::operator= ( const Vector & rhs )									// copy assignment operator=
{
Vector copy = rhs;														// calling copy constructor
std::swap( *this, copy );
return *this;
}

template <typename T>   
Vector<T> & Vector<T>::operator= ( Vector && rhs )										// move assignment operator=
{    
std::swap( theSize, rhs.theSize );
std::swap( theCapacity, rhs.theCapacity );
std::swap( array, rhs.array );
        
return *this;
}

template <typename T>
T & Vector<T>::at(int index)
{
if(index>=0 && index<theSize)
	return array[index];
else
	throw std::out_of_range("exit");
}

template <typename T>
const T & Vector<T>::at(int index) const
{
if(index>=0 && index<theSize)
        return array[index];
else
      	throw std::out_of_range("exit");
}

template <typename T>
T & Vector<T>::front()
{
return array[0];
}

template <typename T>
const T & Vector<T>::front() const
{
return array[0];
}

template <typename T>
T & Vector<T>::back()
{
return array[theSize-1];
}

template <typename T>
const T & Vector<T>::back() const
{
return array[theSize-1];
}

template <typename T>
int Vector<T>::size( ) const
{
return theSize;
}

template <typename T>
int Vector<T>::capacity( ) const
{
return theCapacity;
}

template <typename T>
bool Vector<T>::empty( ) const
{
return size( ) == 0;
}

template <typename T>
void Vector<T>::clear()													
{
theSize = 0;
theCapacity = 0;
}

template <typename T>
void Vector<T>::push_back( const T & x )                                                                            		// copy x
{
if( theSize == theCapacity )
reserve(2 * theCapacity + 1);                                                                             			// memory allocation is expensive
array[ theSize++ ] = x;
}

template <typename T>
void Vector<T>::pop_back( )
{
--theSize;
}

template <typename T>
const T & Vector<T>::operator[]( int index ) const
{
	return array[ index ];													// no error checking
}

template <typename T>   
void Vector<T>::resize(int num, T val)
{
	if(num>theSize)
	{
	T *newArray = new T[num];
		
	for (int i=0; i<theSize; ++i)
	newArray[i]=std::move(array[i]);

	for(int i=theSize; i<num; ++i)
	newArray[i]=val; 
		
	theSize = num;
	theCapacity = num;
	std::swap (array,newArray);
	delete [ ] newArray;
	newArray = nullptr; 
	}
	else
		theSize = num;	
}

template <typename T>
void Vector<T>::reserve( int newCapacity )
{
if( newCapacity <= theSize )
return;

T *newArray = new T[ newCapacity ];
for( int k = 0; k < theSize; ++k )
newArray[ k ] = std::move( array[ k ] );

theCapacity = newCapacity;
std::swap( array, newArray );
delete [ ] newArray;
}

template <typename T>
void Vector<T>::print(std::ostream& os, char ofc) const
{
for(int i=0; i<theSize; ++i)
os << array[i]<<ofc;
}

template <typename T>     
typename Vector<T>::iterator Vector<T>::begin( )
{
return &array[ 0 ]; 
}

template <typename T>    	
typename Vector<T>::const_iterator Vector<T>::begin( ) const
{ 
return &array[ 0 ]; 
}

template <typename T>    	
typename Vector<T>::iterator Vector<T>::end( )
{ 
return &array[ size( ) ]; 
}

template <typename T>    	
typename Vector<T>::const_iterator Vector<T>::end( ) const
{ 
return &array[ size( ) ]; 
}

template <typename T>
typename Vector<T>::iterator Vector<T>::insert(iterator itr, const T& val)					
{
auto temp = itr;

	if(theCapacity==0)
	theCapacity=1;

	else if(theCapacity==theSize)
	doubleCapacity();
	

T * newArray = new T[theCapacity];
auto element = itr - &array[0];

for(int i=0; i<element; ++i)
newArray[i]=std::move(array[i]);
	
newArray[element]=val;
auto rest= (&array[theSize] - &array[0]) + 1;

for(int i=element; i<rest;++i)
newArray[i+1]=std::move(array[i]);

std::swap(newArray,array);
theSize=theSize+1;
delete [ ] newArray;
newArray = nullptr;
	
return temp;	
}

template <typename T>
typename Vector<T>::iterator Vector<T>::erase(iterator itr)
{
iterator temp= itr;
auto test = &array[ size( ) ];	

	for(auto i = itr; i<test; i++)
	{
	*itr=*(itr+1);
	itr = itr+1;
	}
theSize = theSize - 1;

	return temp;
}

template <typename T>
typename Vector<T>::iterator Vector<T>::erase(iterator start, iterator end)
{
int range = end - start;
iterator temp = start;
auto test = &array[ size( ) ];

	for(auto i = end; i<test; i++)
	{
	*start = *end;
	start = start + 1;
	end = end + 1;
	}
theSize = theSize - range;

	return temp; 	
}

template <typename T>
void Vector<T>::doubleCapacity()
{
if (theCapacity==0)
	theCapacity=1;
else
	reserve(theCapacity*2);
}

template <typename T>
bool operator== (const Vector<T> & lhs, const Vector<T> &rhs)
{
	if(rhs.size()!=lhs.size())
		return false;

	else
	{
		for (int i=0;i<rhs.size();i++)
                {
                if(rhs[i]!=lhs[i])
                        return false;
                }
                return true;
	}
}

template <typename T>
bool operator!= (const Vector<T> & lhs, const Vector<T> &rhs)
{
return !(lhs==rhs);	
}

template <typename T>
std::ostream & operator<< (std::ostream &os, const Vector<T> &v)
{
	v.print(os);
return os;
}


